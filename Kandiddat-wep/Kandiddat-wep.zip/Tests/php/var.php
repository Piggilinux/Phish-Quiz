<?php
// $answer_arr = array();
// $GLOBALS["answer_arr"] = array();
// $testWalker = 1;

 ?>
