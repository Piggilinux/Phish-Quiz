<?php session_start(); ?>
<!DOCTYPE html>
<h1>Thank you for participating!!</h1>
<h2> Down here are your results..</h2>
