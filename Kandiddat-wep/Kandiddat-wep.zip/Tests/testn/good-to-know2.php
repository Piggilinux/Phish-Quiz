<?php session_start(); ?>
<!DOCTYPE html>
<h1>Non Phish information</h1>

<div class="checklist">

    <form action="./testHandler2.php">
        <input type="submit" value="I'm ready for next part!"></p>
    </form>
</div>
